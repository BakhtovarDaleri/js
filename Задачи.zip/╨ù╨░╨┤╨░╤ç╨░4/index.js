let index = 0; // Счетчик

let name1 = prompt("Введите имя первого человека:");
let age1 = prompt("Введите возраст первого человека:");
index++;

console.log(index, name1, age1);

let name2 = prompt("Введите имя второго человека:");
let age2 = prompt("Введите возраст второго человека:");
index++;

console.log(index, name2, age2);

let name3 = prompt("Введите имя третьего человека:");
let age3 = prompt("Введите возраст третьего человека:");
index++;

console.log(index, name3, age3);

console.log(
  "Средний возраст пользователей:",
  (Number(age1) + Number(age2) + Number(age3)) / index
); // Считаем средний возраст пользователей
